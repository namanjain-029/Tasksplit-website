// signup-validation.js

function validateSignUpForm() {
    const name = document.querySelector('input[name="name"]');
    const email = document.querySelector('input[name="email"]');
    const password = document.querySelector('input[name="password"]');
    const confirmPassword = document.querySelector('input[name="confirmPassword"]');
    
    clearErrors();

    // Validate Name
    if (name.value.trim() === "") {
        showError(name, "Full name is required");
        return false;
    }

    // Validate Email
    if (!validateEmail(email.value)) {
        showError(email, "Please enter a valid email");
        return false;
    }

    // Validate Password
    if (password.value.trim() === "") {
        showError(password, "Password is required");
        return false;
    }

    // Validate Confirm Password
    if (confirmPassword.value.trim() === "") {
        showError(confirmPassword, "Please confirm your password");
        return false;
    }

    // Check if passwords match
    if (password.value !== confirmPassword.value) {
        showError(confirmPassword, "Passwords do not match");
        return false;
    }

    return true;  // If all validations pass
}

// Utility functions for form validation
function showError(input, message) {
    const errorDiv = document.createElement('div');
    errorDiv.classList.add('error');
    errorDiv.innerText = message;
    input.parentElement.appendChild(errorDiv);
    input.classList.add('error-border');
}

function clearErrors() {
    const errors = document.querySelectorAll('.error');
    errors.forEach(error => error.remove());

    const errorInputs = document.querySelectorAll('.error-border');
    errorInputs.forEach(input => input.classList.remove('error-border'));
}

// Email validation regex
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}

// Add event listener to your form submit button
document.querySelector('form.signup-form').addEventListener('submit', function (e) {
    if (!validateSignUpForm()) {
        e.preventDefault();  // Prevent form submission if validation fails
    }
});
