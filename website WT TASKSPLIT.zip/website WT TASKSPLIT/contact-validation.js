document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.querySelector('.contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            const name = document.querySelector('input[placeholder="Your Name"]').value.trim();
            const email = document.querySelector('input[placeholder="Your Email"]').value.trim();
            const message = document.querySelector('textarea[placeholder="Tell us about your project"]').value.trim();
            
            if (validateContactForm(name, email, message)) {
                console.log('Contact form is valid. Submitting...');
                contactForm.submit();
            }
        });
    }
});

function validateContactForm(name, email, message) {
    let isValid = true;
    
    if (name === '') {
        showError('input[placeholder="Your Name"]', 'Name is required');
        isValid = false;
    } else {
        clearError('input[placeholder="Your Name"]');
    }
    
    if (email === '') {
        showError('input[placeholder="Your Email"]', 'Email is required');
        isValid = false;
    } else if (!isValidEmail(email)) {
        showError('input[placeholder="Your Email"]', 'Please enter a valid email address');
        isValid = false;
    } else {
        clearError('input[placeholder="Your Email"]');
    }
    
    if (message === '') {
        showError('textarea[placeholder="Tell us about your project"]', 'Message is required');
        isValid = false;
    } else {
        clearError('textarea[placeholder="Tell us about your project"]');
    }
    
    return isValid;
}

function isValidEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

function showError(selector, errorMessage) {
    const field = document.querySelector(selector);
    let errorElement = field.nextElementSibling;
    
    if (!errorElement || !errorElement.classList.contains('error-message')) {
        errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        field.parentNode.insertBefore(errorElement, field.nextSibling);
    }
    
    errorElement.textContent = errorMessage;
    field.classList.add('error');
}

function clearError(selector) {
    const field = document.querySelector(selector);
    const errorElement = field.nextElementSibling;
    
    if (errorElement && errorElement.classList.contains('error-message')) {
        errorElement.remove();
    }
    
    field.classList.remove('error');
}