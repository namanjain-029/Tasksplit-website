document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.querySelector('.login-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            const email = document.querySelector('input[type="email"]').value.trim();
            const password = document.querySelector('input[type="password"]').value.trim();
            
            if (validateLoginForm(email, password)) {
                console.log('Login form is valid. Submitting...');
                loginForm.submit();
            }
        });
    }
});

function validateLoginForm(email, password) {
    let isValid = true;
    
    if (email === '') {
        showError('input[type="email"]', 'Email is required');
        isValid = false;
    } else if (!isValidEmail(email)) {
        showError('input[type="email"]', 'Please enter a valid email address');
        isValid = false;
    } else {
        clearError('input[type="email"]');
    }
    
    if (password === '') {
        showError('input[type="password"]', 'Password is required');
        isValid = false;
    } else if (password.length < 6) {
        showError('input[type="password"]', 'Password must be at least 6 characters long');
        isValid = false;
    } else {
        clearError('input[type="password"]');
    }
    
    return isValid;
}

function isValidEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

function showError(selector, errorMessage) {
    const field = document.querySelector(selector);
    let errorElement = field.nextElementSibling;
    
    if (!errorElement || !errorElement.classList.contains('error-message')) {
        errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        field.parentNode.insertBefore(errorElement, field.nextSibling);
    }
    
    errorElement.textContent = errorMessage;
    field.classList.add('error');
}

function clearError(selector) {
    const field = document.querySelector(selector);
    const errorElement = field.nextElementSibling;
    
    if (errorElement && errorElement.classList.contains('error-message')) {
        errorElement.remove();
    }
    
    field.classList.remove('error');
}